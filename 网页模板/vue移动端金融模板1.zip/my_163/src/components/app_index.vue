<template>
  <div>
    <div>
    <van-row type="flex" justify="space-between" style="width:100%;">
      <van-col>
        <h2 class="logo_set">碳金融</h2>
      </van-col>
      <van-col>
        <van-search placeholder="请输入搜索关键字" shape="round" right-icon="service"></van-search>
      </van-col>
      <van-col>
        <div class="loginBtn">
          登陆
          </div>
      </van-col>
    </van-row>

    <div class="base_item">
      <van-grid :border="false">
        <van-grid-item icon="column" text="我的账户" color="#00be00"/>
        <van-grid-item icon="gold-coin" text="我的资产" />
        <van-grid-item icon="clock" text="我的明细" />
        <van-grid-item icon="gift-card" text="我的支付" />
      </van-grid>
    </div>

    <van-swipe :autoplay="4000" :height="200" :speed="30" class="swipe_set" :show-indicators="false">
          <van-swipe-item v-for="(image, index) in images" :key="index">
            <img v-lazy="image"/>
          </van-swipe-item>
    </van-swipe>

    <van-notice-bar left-icon="volume-o" :scrollable="false" mode="link">
      <van-swipe
        vertical
        class="notice-swipe"
        :autoplay="5000"
        :show-indicators="false"
        :speed="30"
      >
        <van-swipe-item> 宏观<span class="light_text"> 金融委会议重申稳字当头 坚决防控金融风险</span> </van-swipe-item>
        <van-swipe-item> 宏观<span class="light_text"> 预期汇率制度将保持稳定</span> </van-swipe-item>
      </van-swipe>
    </van-notice-bar>
    
    <van-divider style="width:90%;margin-left:5%"/>

    <van-grid :column-num="5" :border="false" id="common_service">
      <van-grid-item icon="balance-list-o" text="存款" />
      <van-grid-item icon="user-o" text="智注册" />
      <van-grid-item icon="cash-back-record" text="贷款" />
      <van-grid-item icon="home-o" text="生活缴费" />
      <van-grid-item icon="after-sale" text="投资理财" />
      <van-grid-item icon="balance-pay" text="小微金融" />
      <van-grid-item icon="ecard-pay" text="融e借" badge="优惠"/>
      <van-grid-item icon="diamond-o" text="贵金属" />
      <van-grid-item icon="envelop-o" text="工银信使" />
      <van-grid-item icon="apps-o" text="全部" badge="有福利" />
    </van-grid>

    <van-swipe :autoplay="6500" :height="80" :speed="30" class="swipe_set2">
      <van-swipe-item v-for="(image, index) in images2" :key="index">
        <img v-lazy="image" >
        <span>广告</span>
      </van-swipe-item>
    </van-swipe>

    <van-row type="flex" justify="space-between" class="bank_diary">
      <van-col>
        <h3>金融日历</h3>
      </van-col>
      <van-col>
        <span>更多</span>
      </van-col>
      
    </van-row>

    <!-- 金融日历模块 -->
    <div class="bank_diary_info">
      <van-row type="flex" class="diary_title">
        <van-col>
            <span class="day">25</span>
            <span class="weekday">星期二</span>
        </van-col>
        <van-col>
            <span>2021年5月</span>
            <span>亲爱的朋友, 上午好</span>
        </van-col>
        <van-col>
            <span>点击获取天气信息 <van-icon name="arrow" style="position:absolute;margin-left:5px;top:35%;"/> </span>
        </van-col>
      </van-row>

      <van-row type="flex" class="diary_info">
        <van-col style="margin:3% 1% 0 3%;">
          <van-icon name="point-gift-o" :size="20" color="#ee0a24" />
        </van-col>
        <van-col style="margin:3% 0;">
          <span style="font-size:16px;font-weight:700;">微信收余额变动提醒</span>
          <span style="font-size:12px;display:block;color:#504f4f;">账单变动 即时掌握</span>
        </van-col>
        <van-col>
          <img src="" alt="">
        </van-col>
      </van-row>

      <van-divider style="width:90%;margin:0;margin-left:5%;"/>

      <van-row type="flex" class="diary_info2">
        <van-col style="margin:3% 1% 5% 3%;">
          <van-icon name="bullhorn-o" :size="20" color="#ed6a0c"/>
        </van-col>
        <van-col style="margin:3% 0;">
          <span style="font-size:16px;font-weight:700;">签短信信使享好礼</span>
        </van-col>
        <van-col>
          <span style="position:absolute; right:6%; margin-top:3%; padding:2px 5px 2px 5px; font-size:14px; color:orange; border: 1px solid orange; border-radius:20px;">立即签约</span>
        </van-col>
      </van-row>

    </div>
  </div>

      <van-tabbar v-model="active" :placeholder="true" style="margin-top:10px;">
          <van-tabbar-item icon="like-o">最爱</van-tabbar-item>
          <van-tabbar-item icon="debit-pay" dot>信用卡</van-tabbar-item>
          <van-tabbar-item icon="chart-trending-o" dot>智理财</van-tabbar-item>
          <van-tabbar-item icon="shop-collect-o" dot>惠优选</van-tabbar-item>
          <van-tabbar-item icon="user-circle-o" badge="5">我的</van-tabbar-item>
      </van-tabbar>

  </div>

  
</template>

<script>
export default {
  name: 'app_index',
  data () {
    return {
      active: 0,
      images: [
        '/static/img/swipe1_img1.jpg',
        '/static/img/swipe1_img2.jpg',
      ],
      images2:[
        '/static/img/swipe2_img1.jpg',
        '/static/img/swipe2_img2.jpg',
        '/static/img/swipe2_img3.jpg',
        '/static/img/swipe2_img4.jpg',
        '/static/img/swipe2_img5.jpg',
      ]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>


.swipe_set img{
  height: 100%;
  width: 100%;
}


.swipe_set2 img{
   height: 100%;
   width: 90%;
   margin: 0 0 0 4%;
   border: 5px solid #ffffff00;
   border-radius:15px; 
}

.swipe_set2 .van-swipe__indicators{
  bottom: 5%;
  left:15%;
}

.swipe_set2 span{
  position: absolute;
  bottom: 0;
  right: 5%;
  background-color: #00000069;
  color: white;
  font-size: 8px;
  width: 30px;
  z-index: 2;
  border: 3px solid #ffffff00;
  border-radius: 15px 0 5px 0;
  text-align: center;
}

.swipe_set2 .custom-indicator {
    position: absolute;
    right: 5px;
    bottom: 5px;
    padding: 2px 5px;
    font-size: 12px;
    background: rgba(0, 0, 0, 0.1);
  }

#common_service .van-grid-item:nth-child(7n) .van-info{
  width:40px;
}

#common_service .van-grid-item:last-child .van-info{
  width:50px;
}

.light_text{
  color: #000000;
}

.logo_set{
  margin-right: 0.6rem;
  margin-left: 1.4rem;
  font-size: 18px;
  color: #00be00;
}

.loginBtn{
  font-size: 18px;
  padding: 0 7px 0 7px;
  border: 1px solid #ff4444;
  color: #ff4444;
  border-radius: 5px;
  line-height: 34px;
  margin-top: 8px;
  margin-right: 10px;
}


.notice-swipe {
    height: 40px;
    line-height: 40px;
}

.bank_diary{
  margin: 0 4%;
}

.bank_diary span{
  color: #525151;
}

.bank_diary span{
    line-height: 62px;  
}

.bank_diary_info{
  margin: 0 3%;
  border: 2px solid #b9b9b9;
  border-radius: 5px;

}

.diary_title{
  border-bottom: 1px solid #e4e4e4;
}

.diary_title .van-col:first-child span:first-child {
  font-size: 24px;
  font-weight: 700;
  margin-left: 10%;
}

.diary_title .van-col:first-child span:last-child{
  display: block;
  font-size: 8px;
}

.diary_title .van-col:first-child{
  margin: 3%;
}

.diary_title .van-col:nth-child(2n){
  margin: 3% 0;
  line-height: 21px;
  
}

.diary_title .van-col:nth-child(2n) span{
  color: #838383;
}

.diary_title .van-col:nth-child(2n) span:last-child{
  display: block;
  font-size: 16px;
}

.diary_title .van-col:nth-child(2n) span:first-child{
  font-size: 13px;
}


.diary_title .van-col:last-child span{
  position: absolute;
  display: inline-block;
  width: 50px;
  right: 8%;
  margin-top: 4%;
  font-size: 12px;
}

[class*=van-hairline]::after{
  border-top: 2px solid #818080;
}

</style>
